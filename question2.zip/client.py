import os
import pickle
from cryptography.fernet import Fernet

def fun(name,password):
    s = {"username":name,"password":password}
    safecode = pickle.dumps(s)
    with open("users.json","wb") as f:
        f.write(safecode)
    return safecode

if __name__ == '__main__':
    u = input("Username : ")
    p = input("Password : ")
    key = Fernet.generate_key()
    fernet = Fernet(key)
    encP = fernet.encrypt(p.encode())
    yo_fun = fun(u,encP)
